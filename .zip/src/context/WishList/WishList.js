import axios from 'axios'
import React, { createContext, useContext, useEffect, useState } from 'react'
import { AuthContext } from '../AuthContext/AuthContextProvider'



export const wishListContext =createContext();
function WishListProvider({children}) {
    // authentication context
    const{token}=useContext(AuthContext);
    // create states to get the data of product 
    const [allproductswishlist, setAllProductswishlist] = useState([]);

    // logged user wishlist
   async function userWishList(){
    const booleanr= await axios.get(`https://route-ecommerce.onrender.com/api/v1/cart`,{
        headers:{token:localStorage.getItem("tkn")}
    })
    .then((response)=>{
        console.log("resp",response.data);
      setAllProductswishlist(response.data.data.products);
      
        return true;
    })
    .catch((err)=>{
        console.log("error",err);
        return false;
    })
    return booleanr;
    }
    // calling the userWishList function onve there is a token -- user logged in -- in mounting phase
    // use token -- need to use the authcontext
    useEffect(()=>{
        userWishList()
    },[token])

    // add product to wishlist
  async  function addProductToWishlist(id){
    return await axios.post(`https://route-ecommerce.onrender.com/api/v1/wishlist`,
        {
            "productId": id
        },
        {headers:{token:localStorage.getItem('tkn')}}
    ).then((res)=>{
        console.log(res)

    })
    .catch((err)=>{
        console.log(err)

    })
    }
    

// remove product from wishlist

async  function removeProductFromWishlist(id){
    const res= await axios.delete(`https://route-ecommerce.onrender.com/api/v1/wishlist/${id}`,
        
        {headers:{token:localStorage.getItem('tkn')}}
    ).then((res)=>{
        console.log(res);
        setAllProductswishlist(res.data.data.products);

    })
    .catch((err)=>{
        console.log(err)

    })
    }
    return <wishListContext.Provider value={{addProductToWishlist,removeProductFromWishlist,userWishList,allproductswishlist, setAllProductswishlist}}>
    
    {children}
    </wishListContext.Provider>
        
    
}

export default WishListProvider
