import React from 'react'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import axios from 'axios';
import { useQuery } from 'react-query';
import { ProgressBar } from 'react-loader-spinner';
function CatogerySlider() {
    var settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 6,
        slidesToScroll: 1,
        
      };


      function getCatogries(){

    return axios.get(`https://route-ecommerce.onrender.com/api/v1/categories`)
      }



      const{data,isLoading}=useQuery("catogeriesSlider", getCatogries);
      if(isLoading){
        return  <div className='bg-primary bg-opacity-50 vh-100 d-flex  justify-content-center align-items-center'>
        <ProgressBar
            visible={true}
            height="100"
            width="100"
            color="#3A645A"
            ariaLabel="progress-bar-loading"
            wrapperStyle={{}}
            wrapperClass=""
        />
    </div>


      }
    return (
        <Slider {...settings}>
            {data.data.data.map((catogery,idx)=> <div key={idx}  style={{ marginTop: '50px', textAlign: 'center' }}>
<img  style={{height:'200px' , marginBottom: '10px' ,textAlign:'center'  }}  src={catogery.image} alt={catogery.image} />
<h4> {catogery.name} </h4>
            </div>
            
            
            
            )}
          
          
        </Slider>
      );
    }





export default CatogerySlider
