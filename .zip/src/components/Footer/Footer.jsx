import React from 'react'

function Footer() {
    return <>
    <div className='bg-light '>
<h2> Get the FreshCart app </h2>
<p> We will send to you a link , open it on your phone and download the app </p>
<input placeholder='email' type='email'/>
<br></br>
    </div>
    
    
    
    
    </>
}

export default Footer
