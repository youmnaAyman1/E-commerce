import React from 'react'
import HomeSlider from '../HomeSlider/HomeSlider'
import Products from '../Products/Products'
import CatogeriesSlider from '../CatogeriesSlider/CatogeriesSlider';
import { useContext } from 'react';
// import { cartContext } from '../Context/CartContext/CartContext';


function Home() {
    // const {addProductToCart}=useContext(cartContext);
    return <>

    <div className='container ' >
            <div className="row align-item-center">
                <div className="col-md-10 ">
                    <HomeSlider/>

                </div>

                <div className="col-md-2">
                        <div>
                            <figure>
                                <img className='w-100 m' src={require("../../images/bags.jpg")} alt={require('../../images/bags.jpg')} />
                            </figure>
                            <figure>
                                <img className='w-100' src={require("../../images/guiter.jpg")} alt={require("../../images/guiter.jpg")} />
                            </figure>
                        </div>
                      

                      



                </div>
            </div>

    </div>
    <div className='w-100'>
      {/* <CatogeriesSlider/> */}
    </div>
    <div className='container' >
                        <Products/>

                        </div>
    </>
        
    
}

export default Home
