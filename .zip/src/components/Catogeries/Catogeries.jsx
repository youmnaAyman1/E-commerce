// CatogeriesWithSubCatogeries.jsx
import React, { useState } from 'react';
import { useQuery } from 'react-query';
import axios from 'axios';
import { ProgressBar } from 'react-loader-spinner';

function CatogeriesWithSubCatogeries() {
  const { isLoading: categoriesLoading, data: categories } = useQuery('allCatogeries', getAllCatogeries);
  const [selectedCategoryId, setSelectedCategoryId] = useState(null);
  const { isLoading: subCategoriesLoading, data: subCategories } = useQuery(
    ['subCatogeries', selectedCategoryId],
    () => getSubCatogeries(selectedCategoryId),
    {
      enabled: !!selectedCategoryId, // Only fetch subcategories when categoryId is selected
    }
  );

  async function getAllCatogeries() {
    return await axios.get(`https://route-ecommerce.onrender.com/api/v1/categories`);
  }

  async function getSubCatogeries(categoryId) {
    return await axios.get(`https://route-ecommerce.onrender.com/api/v1/SubCategories/${categoryId}`);
  }

  const handleCategoryClick = (categoryId) => {
    setSelectedCategoryId(categoryId);
  };

  return (
    <>
      <div className="container w-75 mt-5">
        <div className="row text-center">
          {categoriesLoading ? (
            <div className='bg-primary bg-opacity-50 vh-100 d-flex justify-content-center align-items-center'>
              <ProgressBar visible={true} height='100' width='100' color='#3A645A' ariaLabel='progress-bar-loading' />
            </div>
          ) : (
            categories?.data.data.map((category, idx) => (
              <div key={idx} className="col-md-4">
                <div className='mb-5 border border-2 shadow-sm'>
                  <button className='text-decoration-none' onClick={() => handleCategoryClick(category._id)}>
                    <figure>
                      <img style={{ height: "270px" }} className='w-100 me-2 mb-2' src={category.image} alt={category.name} />
                    </figure>
                    <figcaption>
                      <h3>{category.name}</h3>
                    </figcaption>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {selectedCategoryId && (
        <div className="container w-75 mt-5">
          <div className="row text-center">
            {subCategoriesLoading ? (
              <div className='bg-primary bg-opacity-50 vh-100 d-flex justify-content-center align-items-center'>
                <ProgressBar visible={true} height='100' width='100' color='#3A645A' ariaLabel='progress-bar-loading' />
              </div>
            ) : (
              subCategories?.data.data.map((subCategory, idx) => (
                <div key={idx} className="col-md-4">
                  <h2>{subCategory.name}</h2>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </>
  );
}

export default CatogeriesWithSubCatogeries;
