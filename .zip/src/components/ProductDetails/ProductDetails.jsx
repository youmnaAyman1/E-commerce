import React, { useContext } from 'react';
import axios from 'axios';
import { ProgressBar } from 'react-loader-spinner';
import { useQuery } from 'react-query';
import { Navigate, useParams } from 'react-router-dom';
import { cartContext } from '../../context/CartContext/CartContext';
import toast from 'react-hot-toast';
import { wishListContext } from '../../context/WishList/WishList';


function ProductDetails() {
const {addProductToCart}=useContext(cartContext);
const {addProductToWishlist}=useContext (wishListContext);
//  add product to cart button
 function addProduct(id) {
  const res= addProductToCart(id);
  if (res) {
    toast.success("It has been added successfully",{duration:1600,position:"top-center"});
  } else {
   toast.error("Errot occured",{duration:1600,position:"top-center"});
  }
}

// add product to wish list
 function wishListProducts(id){
 const res= addProductToWishlist(id);

 if (res) {
    toast.success("It has been added successfully",{duration:1600,position:"top-center"});
  } else {
   toast.error("Errot occured",{duration:1600,position:"top-center"});
  }
}




  // const {addProductToCart}=useContext(cartContext);
  const { id } = useParams();
  const { isError, isLoading, data } = useQuery(`ProductDetails-${id}`, getProductDetails);

  function getProductDetails() {
    return axios.get(`https://route-ecommerce.onrender.com/api/v1/products/${id}`);
  }
if(isError){
// must return jsx code thats why we use navigate 
  return <Navigate to='/products'  />
}
  if (isLoading) {
    return (
      <div className='bg-primary bg-opacity-50 vh-100 d-flex justify-content-center align-items-center'>
        <ProgressBar
          visible={true}
          height='100'
          width='100'
          color='#3A645A'
          ariaLabel='progress-bar-loading'
        />
      </div>
    );
  }

  // Check if data is defined before accessing its properties
  const productDetails = data?.data.data;

  // Check if productDetails is undefined before rendering
  if (!productDetails) {
    return <div>Error loading product details</div>;
  }

  return (
    <>
      <div className="container">
        <div className="row align-items-center justify-content-center">
          <div className="col-3">
            <img className='w-100' src={productDetails.imageCover} alt={productDetails.imageCover} />
          </div>
          <div className="col-9">
            <article>
              <h1>{productDetails.title}</h1>
              <p>{productDetails.description}</p>
              <p>{productDetails.category.name}</p>
              <p>{productDetails.price} EGP </p>
              <div className="d-flex">
              <button onClick={()=>addProduct(productDetails.id)} className='w-100 bg-main text-white border-0 m-auto add'> +add to cart </button>
              <button onClick={()=>wishListProducts(productDetails.id)} className='border-0 heartbutton mb-5' > 
              
              <i   className="fa-solid fa-heart fa-2xl heart "  ></i> 
                    
                    </button>
              </div>
              
              
              
            </article>
          </div>
        </div>
      </div>
    </>
  );
}

export default ProductDetails;
