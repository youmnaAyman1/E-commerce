import React from 'react'
import error from'../../images/error.svg'

function NotFound() {
    return <>
    
    <div className='d-flex align-items-center justify-content-center'>
<figure>
    <img style={{width:"700px"}} src={error} alt="Not found" />

</figure>

    
    </div>
    
    
    
    </>
        
    
}

export default NotFound
