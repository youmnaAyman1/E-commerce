import axios from 'axios';
import React from 'react';
import { useFormik, yupToFormErrors } from 'formik';
import * as yup from 'yup';
function ForgetPassword() {
  const formik = useFormik({
    initialValues: {
      email: '',
    },
    validationSchema: yup.object({
      email: yup.string().email('Invalid email address').required('Email is required'),
    }),
    onSubmit: (values) => {
      forgetYourPassword(values.email);
    },
  });

  function forgetYourPassword(email) {
    
    axios
      .post(`https://route-ecommerce.onrender.com/api/v1/auth/forgotPasswords`, {
        email: email,
      })
      .then((response) => {
        console.log(response.data);
      })
      .catch((error) => {
        console.error(error.response.data); // Handle the error accordingly
      });
  }

  return (
    <div className='container'>
      <h2>Please enter your email to receive a verification code</h2>
      <form onSubmit={formik.handleSubmit}>
        <input
        className='form-control mb-2'
          type='email'
          placeholder='Email'
          id='email'
          name='email'
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.email}
        />
        {formik.touched.email && formik.errors.email && (
          <div className='text-danger'>{formik.errors.email}</div>
        )}
        <button type='submit' className='btn btn-outline-success'>
          Verify
        </button>
      </form>
    </div>
  );
}

export default ForgetPassword;
