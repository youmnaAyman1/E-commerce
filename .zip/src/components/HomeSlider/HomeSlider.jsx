import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";


export default function HomeSlider() {
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };
  return (
    <Slider {...settings}>
      <div className="w-100 text-center ">
       <figure>
<img className="m-auto" src={require("../../images/bag.jpg")} alt="" />

       </figure>
      </div>
      <div>
       <figure>
        <img src={require("../../images/accessories.jpg")} alt="" />
       </figure>
      </div>
      
    </Slider>
  );
}