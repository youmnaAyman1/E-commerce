import React from 'react';
import { ProgressBar } from 'react-loader-spinner';

function IsLoading({ isLoading }) {
  if (isLoading) {
    return (
      <div className='bg-primary bg-opacity-50 vh-100 d-flex justify-content-center align-items-center'>
        <ProgressBar
          visible={true}
          height='100'
          width='100'
          color='#3A645A'
          ariaLabel='progress-bar-loading'
        />
      </div>
    );
  }

  return null;
}

export default IsLoading;
