import axios from 'axios';
import React, { useContext, useState } from 'react';
import { ProgressBar } from 'react-loader-spinner';
import { useQuery } from 'react-query';
import { Link } from 'react-router-dom';
import { cartContext } from '../../context/CartContext/CartContext';
import toast from 'react-hot-toast';
import { wishListContext } from '../../context/WishList/WishList';

function Products() {
  const { addProductToCart } = useContext(cartContext);
  const { addProductToWishlist, wishlist, setWishlist } = useContext(wishListContext);

  const [pressedProductIds, setPressedProductIds] = useState(new Set());

  function wishListProducts(id) {
    const res = addProductToWishlist(id);

    if (res) {
      toast.success('It has been added successfully to wl', {
        duration: 1600,
        position: 'top-center',
      });
    } else {
      toast.error('Error occurred', { duration: 1600, position: 'top-center' });
    }
  }

  function addProduct(id) {
    const res = addProductToCart(id);
    if (res) {
      toast.success('Product added successfully', {
        duration: 1600,
        position: 'top-center',
      });
    } else {
      toast.error('Error occurred', { position: 'top-center', duration: 1600 });
    }
    console.log(res);
  }

  const { isError, isFetching, isLoading, data } = useQuery(
    'getAllProducts',
    getAllProducts,
    {
      cacheTime: 1000,
      refetchInterval: 2000,
    }
  );

  function getAllProducts() {
    return axios.get(`https://route-ecommerce.onrender.com/api/v1/products`);
  }

  if (isLoading) {
    return (
      <div className='bg-primary bg-opacity-50 vh-100 d-flex justify-content-center align-items-center'>
        <ProgressBar
          visible={true}
          height='100'
          width='100'
          color='#3A645A'
          ariaLabel='progress-bar-loading'
        />
      </div>
    );
  }

  const isPressed = (id) => pressedProductIds.has(id);

  const handleHeartClick = (id) => {
    setPressedProductIds((prevIds) => {
      const newIds = new Set(prevIds);
      if (newIds.has(id)) {
        newIds.delete(id);
      } else {
        newIds.add(id);
      }
      return newIds;
    });

    wishListProducts(id);
  };

  return (
    <>
      <div className='container '>
        <div className=' products row   g-5  '>
          {data?.data.data.map((product, idx) => (
            <div key={idx} className='col-md-3  '>
                    <div className=' product bg-light postion-relative'>
                    <button  onClick={() => handleHeartClick(product.id)} className={`border-0 bg-transparent heart position-absolute ${isPressed(product.id) ? 'red' : ''}`}>
        <i className='fa-regular fa-heart fa-xl'></i>
      </button>
                <Link className=' text-decoration-none  ' to={`/ProductDetails/${product.id}`}>
                  <figure>
                    <img src={product.imageCover} className='w-100 ' alt={product.title} />
                    <h3>{product.category.name}</h3>
                    <h2>{product.title.split(' ').slice(0, 2).join(' ')}</h2>
                    {product.priceAfterDiscount ? (
                      <div className='d-flex justify-content-between'>
                        <p className='text-decoration-line-through'>{product.price}</p>
                        <p>{product.priceAfterDiscount}</p>
                      </div>
                    ) : (
                      <p>{product.price}</p>
                    )}
                    <p className='text-end'>
                      <i style={{ color: 'yellow' }} className='fa-solid fa-star'></i> {product.ratingsAverage}
                    </p>
                  </figure>
                </Link>
                <div className=' d-flex justify-content-evenly'>
                  <button onClick={() => addProduct(product.id)} className='btn bg-main m-auto d-block flex-grow-1'>
                    + Add to Cart
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default Products;
