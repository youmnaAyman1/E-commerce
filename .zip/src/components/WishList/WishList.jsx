import React, { useContext, useEffect } from 'react';
import { wishListContext } from '../../context/WishList/WishList';
import toast from 'react-hot-toast';

function WishList() {
  const { addProductToWishlist, removeProductFromWishlist, allproductswishlist, setAllProductswishlist } = useContext(wishListContext);
 console.log("alllw",allproductswishlist)

 
  // remove product
  async function yourProductRemoved(id){
    const res=   await removeProductFromWishlist(id);
    if(res){
        toast.success("produced removed",{position:"top-center"})
    }
    else{
        toast.error("error occured",{position:"top-center"})
       }
    }
    
  console.log(allproductswishlist);

  return (
    <div className='container bg-light my-3'>
      <h2>My Wish List</h2>
      {allproductswishlist?.map((productwl, ida) => (
        <div key={ida} className='row'>
          <div className='col-2'>
            <figure>
              <img className='w-100' src={productwl.product.imageCover} alt={productwl.product.title} />
            </figure>
          </div>
          <div className='col-8'>
            <div>
              <h3>{productwl.product.title}</h3>
              <h4>${productwl.price}</h4>
              <button
                className='btn text-danger'
                onClick={() => yourProductRemoved(productwl.product.id)}
              >
                <i style={{ color: 'red' }} className='fa-solid fa-trash'></i> Remove
              </button>
            </div>
          </div>
          <div className='col-2'>
            <button className='btn btn-outline-success'>Add to Cart</button>
          </div>
        </div>
      ))}
    </div>
  );
}

export default WishList;
