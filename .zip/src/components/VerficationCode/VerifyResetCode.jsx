import axios from 'axios'
import React from 'react'

function VerifyResetCode() {
    function verifyYourcode(resetCode){

        axios.post(`https://route-ecommerce.onrender.com/api/v1/auth/verifyResetCode`,
        
            {
                "resetCode":resetCode
            }
    )

    }
    return <>
    

    </>
        
    
}

export default VerifyResetCode
